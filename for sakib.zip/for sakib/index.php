<?php

include('connect.php');


 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="all.min.css">
    <link rel="stylesheet" type="text/css" href="home.css">
    <link rel="stylesheet" type="text/css" href="product.css">
    <title>Document</title>
    <style>
        body{
    height: 100vh;
    background-color:   #d6f5f2;
    display: flex;
    flex-direction: column;
  }
     
.header {
         width: 100%;
         height: 99px;
         background-color:#0d204c ;
         display: flex;
         align-items: center;
         justify-content:space-between;
      
        
         
     }

     .header button {
         width: 100px;
         height: 30px;
         border: none;
         border-radius: 20px;
         color: white;
         background-color:goldenrod;
         margin: 10px;
         cursor: pointer;
         border: gold;
        
     }
 .buy-now-btn
 {
    display: block;
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    background-color: #0d204c;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
}

.buy-now-btn:hover {
    background-color: #d7b56e;
}
.container{
    width: 100%;
    height: auto;
    
    display: flex;
    flex-direction: row;
    justify-content: center;
    flex-flow: wrap;
}
.box{
    width: 29%;
    margin: 27px;
    border-radius: 10px;
    background-color: white;
    box-sizing: border-box;
}
.photo {
  width: 100%;
  height: auto;
  padding: 15px;
  overflow: hidden;

}


/* end of food section*/
.footer_section {
  background-color: #222831;
  color: #ffffff;
  padding: 75px 0 40px 0;
  margin-top: 500px;
  text-align: center;
}
@media screen and (max-width :1440px) {
.box{

    width: 26%;
    
}
}

@media screen and (max-width :768px) {
.box{

    width: 400px;
}
}


    </style>
</head>
<body>
<!-- header section -->
    

<div class="header">  

                <div  style="margin:10px; display: flex;align-items: center;justify-content: space-between;">
                            <div class="logo" style="margin:10px;">
                            <a href="index.php" style="margin-right: 10px;"><img src="images/img.jpg" alt=""></a>
                            </div>
                            <h1>The SakiMoni</h1>
                </div>

<div style="margin:10px; display: flex;align-items: center;justify-content: space-between;">
                <div class="nav" style="color:#d7b56e; ">

                       <a href="index.php"style="color:#d7b56e ;">•  Home</a>
                        <a href="videos.php" style="color:#d7b56e ;"  >• Videos</a>
                       <a href="contact.php" style="color:#d7b56e ;" >• Contact</a>
                </div>



   <div class="button">
 <a href="admin.php?logout=1" style="color: white;"><button style="color: aliceblue;">admin</button></a> 
                                           
                    </div> 
 </div>
 </div>


<!--end  section -->


   <br>

    

<!-- food section -->

 <div class="container">

<?php
$res = mysqli_query($conn, "select * from data");
while ($row = mysqli_fetch_assoc($res)) {
?>

<tr>
 
<div class="box">

<div class="photo">


<img src="Images/<?php echo    $row['file']; ?>" style=" width:100%; ">
<div style="  margin-top: auto;
color: black;" >

<h3> <?php echo    $row['title']; ?></h3> <br>
<h3 style="color: gold;">$ <?php echo    $row['title1']; ?></h3><br>


</div>


<div style="  margin-top: auto;
padding: 25px;
background-color: black;
color: #ffffff;" >
<?php echo    $row['content']; ?><br>
</div>
<a href="admin.php" ><button class="buy-now-btn">Add to cart</button></a>
<a href="admin.php"><button class="buy-now-btn">Buy Now</button></a>
</div>
</div>


</tr>
<?php }?>
</table>
</div>



<!-- food section -->



  <!-- footer section -->


  <footer>
    <div class="container">
        <div class="row">
            <div class="footer-content">
                <div class="footer-section about">
                    <h2>About Us</h2>
                    <p>I am a simple boy who love food named Nesarul Sakib A.K.A The SakiMoni. A Bengali Content Creator from Bangladesh 🇧🇩.</p>
                </div>
                <div class="footer-section contact">
                    <h2>Contact Us</h2>
                    <p>Email: info@sakimoni.com</p>
                    <p>Phone: +1 (123) 456-7890</p>
                </div>
                <div class="footer-section social">

            <h2 class="text">SOCIAL MEDIA</h2>
        <div class="social">
        <div class="hover link">
          <ul>
            <li><a href="https://www.facebook.com/thesakimoni">Facebook</a></li>
          </ul>
          <ul>
            <li><a href="https://www.instagram.com/thesakimoni">Instagram</a></li>
          </ul>
          <ul>
            <li><a href="https://www.youtube.com/@TheSakiMoni/videos">Youtube</a></li>
          </ul>
          
        </div>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; 2024 The SakiMoni. All Rights Reserved.</p>
    </div>
</footer>
  <!-- footer section -->
</body>
</html>