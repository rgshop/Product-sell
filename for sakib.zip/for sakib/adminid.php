<?php

include('connect.php');
if (!isset($_SESSION['USER_ID'])) {
    header("location:login.php");
    die();
}


 ?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Crud operation</title>

</head>
<body>


<br><br>
<center>
<h1>Admin Post</h1>
</center>
<hr>

    <!-- -->

<div class=" container my-5">
<a href="admin.php"><button  class="btn btn-primary">Back</button></a>
    </div>
    <!-- -->

      
            <!-- -->
    <div class=" container my-5">
    <table class="table table-striped"  >
    <thead>
        <tr >
            <th scope="col" >SL No.</th>
            <th scope="col">Email</th>
            <th scope="col">Password</th>
            <th scope="col">Operation</th>
        </tr>
    </thead>

    <tbody>
    <?php
$res = mysqli_query($conn, "select * from user");
while ($row = mysqli_fetch_assoc($res)) {
    ?>
    
    <td><?php echo    $row['id']; ?>
    </td>
    

    <td><?php echo    $row['email']; ?>
    </td>
    <td> <?php echo    $row['password']; ?>
    </td>


    <td><?php $id = $row['id'];  echo '
                <button class="btn btn-primary" ><a href="updateid.php?updateid=' . $id . '"  class="text-light">Update</a></button>
             
                
                '?>
                
</td>  



    </tr>
    <?php }?>
    </table>
    </div>


    <!-- -->
 
    </body>

</html>