<?php

include('connect.php');
if (!isset($_SESSION['USER_ID'])) {
    header("location:login.php");
    die();
}


 ?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Crud operation</title>
    <style>
        .games {
            width: 80%;
            margin: 0 auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
           
        }
        .games  .game {
            width: 100px;
            height: 100px;
            margin: 10px;
            position: relative;
           
          
        }
        .games .game img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
        }
     
    </style>
</head>
<body>


<br><br>
<center>
<h1>Admin Post</h1>
</center>
<hr>

    <!-- -->

<div class=" container my-5">
<a href="admin.php"><button  class="btn btn-primary">Back</button></a>
    </div>
    <!-- -->

      
            <!-- -->
    <div class=" container my-5">
    <table class="table table-striped"  >
    <thead>
        <tr >
            <th scope="col" >Photo</th>
            <th scope="col">Title</th>
            <th scope="col">Price</th>
            <th scope="col">Description</th>
            <th scope="col">Operation</th>
        </tr>
    </thead>

    <tbody>
    <?php
$res = mysqli_query($conn, "select * from data");
while ($row = mysqli_fetch_assoc($res)) {
    ?>
    
<tr>
    <td>  <div class="games">
    <div class="game">
    <img src="Images/<?php echo    $row['file']; ?>"/>
    </div>
 </div>
    </td>
    

    <td><?php echo    $row['title']; ?>
    </td>
    <td> $<?php echo    $row['title1']; ?>
    </td>
 
    <td><?php echo    $row['content']; ?>
    </td>


    <td><?php $id = $row['id'];  echo '
                <button class="btn btn-primary" ><a href="update.php?updateid=' . $id . '"  class="text-light">Update</a></button>
                <button class="btn btn-danger" ><a href="delet.php?deletid=' . $id . '" class="text-light">Delete</a></button>
                
                '?>
                
</td>  



    </tr>
    <?php }?>
    </table>
    </div>


    <!-- -->
 
    </body>

</html>