<?php 
 include('connect.php');

 $msg="";
  
if (isset($_POST['submit'])) {
 /* echo "<pre>";
  print_r($_POST);*/
  $email = mysqli_real_escape_string($conn,$_POST['email']);
  $password = mysqli_real_escape_string($conn,$_POST['password']);
  $sql = mysqli_query($conn,"select * from user where email='$email' && password='$password'");
  $num=mysqli_num_rows($sql);
  if ($num>0) {
    /*echo "login";*/
    $row=mysqli_fetch_assoc($sql);
    $_SESSION['USER_ID']=$row['id'];
    $_SESSION['UNSER_NAME']=$row['email'];
    header("location:index.php");
  }
  else{
    $msg="Please Enter Valid Details !";
  }
}





?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>


<div class="login-box"> 
    
<h2>LOGIN</h2>

<form method="post" action="login.php">
<h4 style="color: red;"><?php echo "$msg";  ?></h4>
<div class="input-group">
<!-- <label>Username</label> -->

<input type="email" id="email"   name="email"  placeholder="email"/>
                   
</div>
<div class="input-group">
<!-- <label>Password</label> -->
<input type="password" name="password" placeholder="Password">
</div>

<div class="pass-txt"><a href="forget.php">Forgot password?</a></div>

<div class="input-group">
<button type="submit" class="btn" name="submit">Login</button>

                          
</div>

</form>
<div class="signup">Not yet member? <a href="./signup.php">Signup now</a></div>
</div>
</body>
</html>
