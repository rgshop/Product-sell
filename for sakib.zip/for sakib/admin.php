<?php
include('connect.php');

if (!isset($_SESSION['USER_ID'])) {
    header("location:login.php");
    die();
}


?>

<?php

$user = $_SESSION['UNSER_NAME'];
$query = mysqli_query($conn, "select * from user where email = '$user'");
$row = mysqli_fetch_array($query);


/*echo "$id";*/

if (isset($_POST['submit'])) {
    $title =   $_REQUEST['title'];
    $title1 =   $_REQUEST['title1'];
    $content = $_REQUEST['content'];

    $file_name = $_FILES['image']['name'];
    $tempname = $_FILES['image']['tmp_name'];
    $folder = 'images/'.$file_name; 

    mysqli_query($conn, "insert into data(file,title,title1,content)value('$file_name','$title','$title1','$content')");
        if(move_uploaded_file($tempname, $folder)) {
        echo '<h2>File uploaded successfully</h2>';
        } else{
        echo "<h2>File not uploaded</h2>";
        }
        
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="all.min.css">
    <link rel="stylesheet" type="text/css" href="home.css">
    <link rel="stylesheet" type="text/css" href="product.css">
    <title>Admin Panel</title>

     
<style>
 body{
    background-color:   #d6f5f2;
    display: flex;
    flex-direction: column;
  }
     
.header {
         width: 100%;
         height: 99px;
         background-color:#0d204c ;
         display: flex;
         align-items: center;
         justify-content:space-between;
      
        
         
     }

     .header button {
         width: 100px;
         height: 30px;
         border: none;
         border-radius: 20px;
         color: white;
         background-color:goldenrod;
         margin: 10px;
         cursor: pointer;
         border: gold;
        
     }
  

.container{
    width: 100%;
    height: auto;
    display: flex;
    flex-direction: row;
    flex-flow: wrap;
    justify-content: center;
}
.box{
    width: 45%;
    margin: 20px;
  
    
    box-sizing: border-box;
}
@media screen and (max-width :1440px) {
.box{

    width: 40%;
    
}
}

@media screen and (max-width :768px) {
.box{

    width: 400px;
}
}

/* food section */



.photo {
  width: 100%;
  height: 250px;
  border-radius: 15px 15px 0 0;


overflow: hidden;

}


/* end of food section*/



/* footer section*/
.footer_section {
  background-color: #222831;
  color: #ffffff;
  padding: 75px 0 40px 0;
  margin-top: 1000px;
  text-align: center;
}





</style>
<html>


</head>

<body >
<!-- header section -->
    

<div class="header">  

                <div  style="margin:10px; display: flex;align-items: center;justify-content: space-between;">
                            <div class="logo" style="margin:10px;">
                            <a href="index.php" style="margin-right: 10px;"><img src="images/img.jpg" alt=""></a>
                            </div>
                            <h1>The SakiMoni</h1>
                </div>

<div style="margin:15px; display: flex;align-items: center;">
            

   <div class="button">
   <a href="adminid.php" style="color:#d7b56e ;">• Users</a>
   <a href="view_post.php" style="color:#d7b56e ;"  >• View Post</a>
                 
<a href="logout.php" style="color: white;"><button style="color: aliceblue;">Logout</button></a> 
<a href="index.php" style="color: white;"><button style="color: aliceblue;">Website</button></a>             
                    </div> 
 </div>
 </div>



<!--end header section -->


    <div class=" container my-5" action="#" method="REQUEST">
        <table class="table table-striped" action="#" method="REQUEST">
            <thead>
                <tr>
                    <th scope="col" style="color: white;">Post</th>
                 

                </tr>
            </thead>
            <tbody>
                <td>
                    <form method="POST" enctype="multipart/form-data">
                    <input type="file" name="image" /><br><br>
                        
                        <input type="text" id="title" name="title" placeholder="Title"><br><br>
                        <input type="text" id="title1" name="title1" placeholder="Price"><br><br>
                        <textarea name="content" id="content" placeholder="Description"></textarea><br><br>
                        <input type="submit" name="submit" value="Submit">
                    </form>
                </td>

               

            </tbody>

        </table>
                </div>
      <!-- -->



</body>

</html>