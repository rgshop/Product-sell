<?php
include 'connect.php';
include('dbConfig.php');

if (!isset($_SESSION['USER_ID'])) {
    header("location:login.php");
    die();
}
?>

<?php

$user = $_SESSION['UNSER_NAME'];
$query = mysqli_query($conn, "select * from news_user where email = '$user'");
$row = mysqli_fetch_array($query);
$id = $row['id'];

/*echo "$id";*/

if (isset($_REQUEST['submit'])) {
    $title =   $_REQUEST['title'];
    $content = $_REQUEST['content'];
    mysqli_query($conn, "insert into new_post(title,content,user_id)value('$title','$content','$id')");
}




?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Crud operation</title>
<html>

<head>
    <title>News Post</title>
</head>

<body>
<div class=" header">

    <h4>Welcome <?php echo $_SESSION['UNSER_NAME'] ?></h4>


    <h4> <a href="id.php">Users</a></h4>

    <h4><a href="view_post.php">View Post</a></h4>


    <a href="logout.php"> <button>LOG OUT</button> </a>
    </div>


    <div class=" container my-5" action="#" method="REQUEST">
        <table class="table table-striped" action="#" method="REQUEST">
            <thead>
                <tr>
                    <th scope="col">Profile</th>
                    <th scope="col">Profile</th>

                </tr>
            </thead>
            <tbody>

                <td>
                    <form action="#" method="REQUEST">
                        <label for="fname">Title:</label><br><br>
                        <input type="text" id="title" name="title"><br><br>
                        <label for="lname">Description:</label><br><br>
                        <textarea name="content" id="content"></textarea><br><br>
                        <input type="submit" name="submit" value="Submit">
                    </form>
                </td>

                <td>gg</td>

</html>



<?php





$user = $_SESSION['UNSER_NAME'];
$query = mysqli_query($conn, "select * from news_user where email = '$user'");
$rowr = mysqli_fetch_array($query);
$id = $rowr['id'];


$query1 = mysqli_query($conn, "select * from new_post where user_id = '$id'");
$result = mysqli_num_rows($query1);

?>










<!-- -->
<div class=" container my-5">
    <table class="table table-striped">
        <thead>
            <tr>

                <th scope="col">Title</th>
                <th scope="col">Content</th>
                <th scope="col">Content</th>
            </tr>
        </thead>

        <tbody>

            <?php

            $sql = "Select * from `new_post`";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['id'];
                    $title = $row['title'];
                    $content = $row['content'];
                    echo ' <tr>
            
            <td>' . $title . '</td>
            <td>' . $content . '</td>
            <td>
                <button class="btn btn-primary" ><a href="update.php?updateid=' . $id . '"  class="text-light">Update</a></button>
                <button class="btn btn-danger" ><a href="delet.php?deletid=' . $id . '" class="text-light">Delete</a></button>
</td>
            ';
                }
            }

            ?>

</div>


</body>

</html>