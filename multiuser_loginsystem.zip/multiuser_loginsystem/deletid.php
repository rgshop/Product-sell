<?php
include 'connect.php';
if(isset($_GET['deletid'])){
$id=$_GET['deletid'];

$sql="delete from `news_user` where id=$id";
$result=mysqli_query($conn,$sql);
if($result){
//echo "Deleted successfull";
header('location:id.php');
}else{
die(mysqli_error($conn));
}
}
?>