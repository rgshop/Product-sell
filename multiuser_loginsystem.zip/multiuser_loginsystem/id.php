<?php
include 'connect.php';
include('dbConfig.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"">
    <title>Crud operation</title>
</head>
<body>
<?php

include 'connect.php';
if (isset($_POST['submit'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "insert into `news_user` (email,password)
    values('$email','$password')";

    $result = mysqli_query($con, $sql);
    if ($result) {
        // echo "Data inserted successfully";
        header('location:id.php');
    } else {
        die(mysqli_error($conn));
    }
}

?> 
<br><br>
<center>
<h1>Users</h1>
</center>
<hr>
<div class=" container my-5">
<a href="index.php"><button type="submit" name="submit" style="height: 35px; outline: none;border: none; background: #087cfc; color:aliceblue">Home</button></a>
   
    </div>
    <div class=" container my-5">
   
        <table class="table table-striped" >
            <thead>
                <tr>
                    <th scope="col">Sl no</th>
                    <th scope="col">Email</th>
                    <th scope="col">Password</th>
                    <th scope="col">Operation</th>
                </tr>
            </thead>

            <tbody>

                <?php

                $sql = "Select * from `news_user`";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        $email = $row['email'];
                        $password = $row['password'];
                        echo ' <tr>
            <th scope="row">' . $id . '</th>
            <td>' . $email . '</td>
            <td>' . $password . '</td>
            <td>
                <button class="btn btn-primary" ><a href="update.php?updateid=' . $id . '"  class="text-light">Update</a></button>
                <button class="btn btn-danger" ><a href="deletid.php?deletid=' . $id . '" class="text-light">Delete</a></button>
</td>
            ';
                    }
                }

                ?>


    </div>

    </body>

</html>