<?php

$conn=new mysqli('localhost', 'root', '','news_admin');

if(!$conn){
    die(mysqli_error($conn));
}

?>