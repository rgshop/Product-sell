<?php
include 'connect.php';
include('dbConfig.php');

if (!isset($_SESSION['USER_ID'])) {
	header("location:login.php");
	die();
}



$user = $_SESSION['UNSER_NAME'];
$query = mysqli_query($conn,"select * from news_user where email = '$user'");
$rowr =mysqli_fetch_array($query);
$id = $rowr['id'];


$query1 = mysqli_query($conn,"select * from new_post where user_id = '$id'");
$result = mysqli_num_rows($query1);

 ?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Crud operation</title>
</head>
<body>


<br><br>
<center>
<h1>Users Post</h1>
</center>
<hr>
<div class=" container my-5">
<a href="index.php"><button type="submit" name="submit" style="height: 35px; outline: none;border: none; background: #087cfc; color:aliceblue">Home</button></a>
   
    </div>


    <!-- -->
    <div class=" container my-5">

        <table class="table table-striped"  >
            <thead>
                <tr >

                    <th scope="col" >Title</th>
                    <th scope="col">Content</th>
					<th scope="col">Operation</th>
                </tr>
            </thead>

            <tbody>
		<?php

                $sql = "Select * from `new_post`";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        $title = $row['title'];
                        $content = $row['content'];
                        echo ' <tr>
            
            <td>' . $title . '</td>
            <td>' . $content . '</td>
            <td>
                <button class="btn btn-primary" ><a href="update.php?updateid=' . $id . '"  class="text-light">Update</a></button>
                <button class="btn btn-danger" ><a href="delet.php?deletid=' . $id . '" class="text-light">Delete</a></button>
</td>
            ';
                    }
                }

                ?>



 

</table>

    </body>

</html>