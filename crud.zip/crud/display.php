<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"">
    <title>Crud operation</title>
</head>
<body>
<?php

include 'connect.php';
if (isset($_POST['submit'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "insert into `crud` (email,password)
    values('$email','$password')";

    $result = mysqli_query($con, $sql);
    if ($result) {
        // echo "Data inserted successfully";
        header('location:display.php');
    } else {
        die(mysqli_error($con));
    }
}

?> 
<div class=" container my-5">

    </div>


    <!-- -->
    <div class=" container my-5">
    <div class=" container my-5">
        <form method="post" style="text-align: end;">


            <input type="email" style="height: 35px;  outline: none;" placeholder="Enter email" name="email" autocomplete="off" required>

            <input type="password" style="height: 35px; outline: none; " placeholder="Enter password" name="password" autocomplete="off" required>
            <button type="submit" name="submit" style="height: 35px; outline: none;border: none; background: #087cfc; color:aliceblue">Add user</button>

        </form>
        </div>
   
        <table class="table table-striped" >
            <thead>
                <tr>
                    <th scope="col">Sl no</th>
                    <th scope="col">Email</th>
                    <th scope="col">Password</th>
                    <th scope="col">Operation</th>
                </tr>
            </thead>

            <tbody>

                <?php

                $sql = "Select * from `crud`";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        $email = $row['email'];
                        $password = $row['password'];
                        echo ' <tr>
            <th scope="row">' . $id . '</th>
            <td>' . $email . '</td>
            <td>' . $password . '</td>
            <td>
                <button class="btn btn-primary" ><a href="update.php?updateid=' . $id . '"  class="text-light">Update</a></button>
                <button class="btn btn-danger" ><a href="delet.php?deletid=' . $id . '" class="text-light">Delete</a></button>
</td>
            ';
                    }
                }

                ?>


    </div>
    </body>

</html>