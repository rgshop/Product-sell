<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->


  <title>Dashboard | By Code Info</title>
</head>

<body>
  <div class="container1">
    <nav>
      <ul>
        <li><a href="www.fb.com/rehadul2" class="logo">
            <img src="a.png" alt="">
            <span class="nav-item">Admin Panel</span>
          </a></li>



        <li><a href="http://localhost/crud/admin.php">
            <i class="fas fa-home"></i>
            <span class="nav-item" >Home</span>
          </a></li>

          <li><a href="banner.php">
            <i class="fas fa-cog"></i>
            <span class="nav-item">Banner</span>
          </a></li>

        <li><a href="users.php">
            <i class="fas fa-user"></i>
            <span class="nav-item">Users</span>
          </a></li>
      
     


        <li><a href="" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            <span class="nav-item">Log out</span>
          </a></li>
      </ul>
    </nav>


   <!-- -->
    <section class="main">
          <div class="container" >
          <iframe style="border:0; width: 100%; height: 800px; border-radius: 10px;" src="https://www.rgtopup.com/" frameborder="0" allowfullscreen></iframe>

        </div>
  </div>
  <!-- -->


  </section>
  </section>
  </div>
</body>

</html>